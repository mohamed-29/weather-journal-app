/* Global Variables */



// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();
console.log(newDate)


const postData = async ( url = '', projectData = {})=>{
    console.log(projectData);
      const response = await fetch(url, {
      method: 'POST', 
      credentials: 'same-origin',
      headers: {
          'Content-Type': 'application/json',
      },
     // Body data type must match "Content-Type" header        
      body: JSON.stringify(projectData), 
    });

      try {
        const newData = await response.json();
        console.log(newData);
        return newData;
      }catch(error) {
      console.log("error", error);
      }
  }

const myKey = "581605a463c8d9d0802a03689b32d556";

const getTemp=async(Url,feel,date)=>{
    const res=await fetch(Url)
    try{
        const data1=await res.json();
        
        const temp=data1.main.temp;
        console.log(temp);
        //update the UI
        document.getElementById("date").innerHTML="Date : "+date;
        document.getElementById("temp1").innerHTML="Temp in fahrenheit : "+temp;
        let temp1=(temp-32)*5/9;
        document.getElementById("temp2").innerHTML="Temp in celsius : "+temp1;
        document.getElementById("content").innerHTML="Feel : "+feel;


    }
    catch(error){
        console.log("error",error)
    }
}




const generator = document.getElementById("generate");
//event listener to get the zip and update the UI
generator.addEventListener("click",add1)
function add1(){
    console.log ("Generator click");
    //get the zip
    const zip = document.getElementById("zip").value;
    
    if (zip) console.log(zip);
    else console.error("Zip is empty");
    //get the felling
    const feel=document.getElementById("feelings").value;
    console.log(feel);

    //the api url to get data
    let apiUrl=`http:/api.openweathermap.org/data/2.5/weather?zip=${zip},us&appid=${myKey}`
    //call the function
    getTemp(apiUrl,feel,newDate);
    


}



